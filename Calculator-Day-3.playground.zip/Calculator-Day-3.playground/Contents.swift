import UIKit

class calculator{
    var a: Int!
    var b: Int!
    private var result: Int?
    
    init(firstnumber: Int, secondnumber: Int) {
        self.a = firstnumber
        self.b = secondnumber
    }
    
    func add() {
        result = a + b
    }
    
    func sub() {
        result = a - b
    }
    
    func multi() {
        result = a * b
    }
    
    func divid() {
        result = a / b
    }
    
    func displayResult() {
        print(result!)
    }
}

let cal = calculator(firstnumber: 10, secondnumber: 5)
//let suber = calculator(firstnumber: 4, secondnumber: 2)
//let mulitper = calculator(firstnumber: 5, secondnumber: 2)
//let divder = calculator(firstnumber: 10, secondnumber: 2)

cal.add()
cal.displayResult()
cal.sub()
cal.displayResult()
cal.multi()
cal.displayResult()
cal.divid()
cal.displayResult()


