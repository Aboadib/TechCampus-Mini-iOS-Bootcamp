//
//  ViewController.swift
//  LogoAppHomeworkDay4
//
//  Created by Omar alzamil on 13/07/2019.
//  Copyright © 2019 MUL78. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

