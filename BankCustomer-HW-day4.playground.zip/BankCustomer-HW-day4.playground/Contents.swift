import UIKit

class BankCustomerDetail {
    var Name: String!                          //clients name.
    var AccountNumber: String!                 //Account number of client's account.
    var Wallet: Int!                           // total money in client account.
    
    // note: i would have used praivate in declaring var to show that i used access method in my code but i needed those var in print and i couldn't call from diffrent sperate class a func that used in another class. sorry for that :(
    
    init(name: String, accountnum: String, wallet: Int){        // init for all var Name, Account Number and Wallet.
        self.Name = name
        self.AccountNumber = accountnum
        self.Wallet = wallet
    }
    func ToTryOverrideFunc(){             // The perpose of this function is to test and include override func in Playground.
        print("This will not be printed unlees let (contstant) assgin to class \(BankCustomerDetail.self), else if it assigned to class \(BankCustomerOps.self) this will be overroad")
    }
}

class BankCustomerOps : BankCustomerDetail {           // sub Class of the mani class BankCustomer.
    
    override init(name: String, accountnum: String, wallet: Int) {         //The perpose of this is to try, test and includ override of init in my playground.
        super.init(name: accountnum, accountnum: name, wallet: wallet)               // Swaped name & Account number in perpose of trial, test and fun :)
    }
    override func ToTryOverrideFunc(){                // To try, test and include override in my playground.
            print("This will be override the origibal func in \(BankCustomerDetail.self) if and only if let (constant )is assigned to \(BankCustomerOps.self)")
    }
}
class viewer {                             // here is a class just to incoperate the Polymorphism or somthing like that :D
    let Info: [BankCustomerOps]!
    
    init(info: [BankCustomerOps]) {        // init for BankCustomerOp class, Op: operation.
        self.Info = info
    }
    func IsThereDiddction(){               // Here is a way to show, test, try and include overloading in the code.
        print("No Diddction")
    }
    func IsThereDiddction(DiddctionAmount: Int){      // the overloading func. And i hope employeyes won't press charges against me (Don't shot the massnger).
        print(DiddctionAmount)
        for x in Info{
            x.Wallet = x.Wallet - DiddctionAmount
        }
    }
    func PrintWallet(){
        print("the employeys name & wallet is as follow: \n")
        for x in Info{
            print(x.AccountNumber!,"=",x.Wallet!,"\n") //Account number instade of name bcz we swap them in super init (code line 21).
        }
    }
}

let Clients = viewer(info: [BankCustomerOps(name: "ali", accountnum: "SA555", wallet: 2000),BankCustomerOps(name: "Ahmed", accountnum: "SA444", wallet: 3000),BankCustomerOps(name: "Majed", accountnum: "SA200", wallet: 1500),BankCustomerOps(name: "asma", accountnum: "SA234", wallet: 23),BankCustomerOps(name: "alia", accountnum: "SA323", wallet: 5000)])                                    // assigment of constant to respictive class.
Clients.PrintWallet()                                              //print client name & wallet.

Clients.IsThereDiddction()                                        //calling overloading func 1.
Clients.IsThereDiddction(DiddctionAmount: 30)                     //calling overloading func 2.

let TestOverride = BankCustomerOps(name: "", accountnum: "", wallet: 0)
TestOverride.ToTryOverrideFunc()                                                   //calling override func.
let TestOverRide2 = BankCustomerDetail(name: "", accountnum: "", wallet: 0)
TestOverRide2.ToTryOverrideFunc()                                                  //calling origin func that overroad brfore.
